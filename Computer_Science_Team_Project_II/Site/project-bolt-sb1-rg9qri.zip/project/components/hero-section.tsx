import { MapPin } from "lucide-react";

export function HeroSection() {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
      <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-4">
        <div className="flex-1">
          <div className="flex items-center text-2xl font-bold text-gray-900 mb-2">
            <MapPin className="h-6 w-6 text-red-600 mr-2" />
            Start here
          </div>
          <p className="text-gray-600">Find your store to see local deals</p>
        </div>
        <div className="flex-1 w-full">
          <input
            type="text"
            placeholder="Enter your address for delivery"
            className="w-full px-4 py-2 border border-gray-300 rounded-l focus:outline-none focus:ring-2 focus:ring-red-500"
          />
        </div>
        <button className="w-full md:w-auto px-6 py-2 bg-red-600 text-white font-semibold rounded hover:bg-red-700 transition-colors">
          FIND DEALS
        </button>
      </div>
      <div className="flex justify-center space-x-4 mt-6">
        <button className="flex items-center px-6 py-2 border-2 border-red-600 text-red-600 font-semibold rounded hover:bg-red-50 transition-colors">
          CARRYOUT
        </button>
        <button className="flex items-center px-6 py-2 border-2 border-red-600 text-red-600 font-semibold rounded hover:bg-red-50 transition-colors">
          DELIVERY
        </button>
      </div>
    </div>
  );
}